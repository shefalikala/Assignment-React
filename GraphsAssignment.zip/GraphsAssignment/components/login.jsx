import React from 'react';
import ReactDOM from 'react-dom';
import { Link, Router, Route, IndexRoute, hashHistory } from "react-router";
import ReactBootstrap from 'react-bootstrap';


import  { Radio,ListGroupItem,ListGroup,Carousel ,FormGroup ,ControlLabel ,FormControl ,Label,Accordion, Panel, Modal ,Button, ButtonGroup, OverlayTrigger , Popover,Tabs , Tab, DropdownButton, MenuItem, ProgressBar } from 'react-bootstrap';
import Header from './header.jsx';
import Success from './Modals/success.jsx';


var inputlabelArray = [];
var inputValue = [];
const Login = React.createClass({
 getInitialState() {
    return {inputlabelArray:[], inputValue:[],showpop:false};
      
  },
  showPop()
  {
    this.setState({showpop:true})
  },
  hidePop()
  {
    this.setState({showpop:false})
  },
 onIputFocus:function(refName){  
  inputlabelArray[refName]= true;
},
onInputChange:function(refName,val){
    inputValue[refName]=val.value;
    console.log("inputValue: " + val);
    this.setState({inputValue:inputValue});

},
onInputBlur:function(refName,ev){
  console.log("refName",refName);
  if(!this.state.inputValue.hasOwnProperty(refName)){
      inputlabelArray[refName]= false;
  }else{
      inputlabelArray[refName]= true;
  }
  this.setState({inputlabelArray:inputlabelArray});
  if( ev.target.value.trim() === '' ) {
    inputlabelArray[refName]= false;
  }
},
  render() {

    return (
    
    <div className="container">
   
     <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 nopad">
        <div className="middle_section">
         <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 nopad back-white mt20">
          <div className="col-lg-8 col-md-8 col-sm-12 col-xs-12 signup_section">
            <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 nopad">
              <h3>Sign Up Here</h3>
              <ul className="col-xs-12 forms_ul nopad manageUL"> 
               <li className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                          <span className={this.state.inputlabelArray["name"] ? "input input--hoshi input--filled llabelSpan" : "input input--hoshi llabelSpan"}>
                              <input className="input__field input__field--hoshi" value={this.state.inputValue["name"]} onFocus={this.onIputFocus.bind(this,"name")} onBlur={this.onInputBlur.bind(this,"name")} onChange={this.onInputChange.bind(this,"name")} ref="name" type="text" id="name" aria-labelledby="empId"/>
                              <label className="input__label input__label--hoshi input__label--hoshi-color-1" for="name">
                                <span className="input__label-content input__label-content--hoshi candidateLbl" id="empId">Name</span>
                              </label>
                            </span> 

               </li>
               <li className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                          <span className={this.state.inputlabelArray["contact"] ? "input input--hoshi input--filled llabelSpan" : "input input--hoshi llabelSpan"}>
                              <input className="input__field input__field--hoshi" value={this.state.inputValue["contact"]} onFocus={this.onIputFocus.bind(this,"contact")} onBlur={this.onInputBlur.bind(this,"contact")} onChange={this.onInputChange.bind(this,"contact")} ref="contact" type="number" id="contact" aria-labelledby="contact"/>
                              <label className="input__label input__label--hoshi input__label--hoshi-color-1" for="contact">
                                <span className="input__label-content input__label-content--hoshi candidateLbl" id="">Contact Number</span>
                              </label>
                            </span> 

               </li>
               <li className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                          <span className={this.state.inputlabelArray["username"] ? "input input--hoshi input--filled llabelSpan" : "input input--hoshi llabelSpan"}>
                              <input className="input__field input__field--hoshi" value={this.state.inputValue["username"]} onFocus={this.onIputFocus.bind(this,"username")} onBlur={this.onInputBlur.bind(this,"username")} onChange={this.onInputChange.bind(this,"username")} ref="username" type="text" id="username" aria-labelledby="user"/>
                              <label className="input__label input__label--hoshi input__label--hoshi-color-1" for="username">
                                <span className="input__label-content input__label-content--hoshi candidateLbl" id="user">User Name</span>
                              </label>
                            </span> 

               </li>
                <li className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                          <span className={this.state.inputlabelArray["pwd"] ? "input input--hoshi input--filled llabelSpan" : "input input--hoshi llabelSpan"}>
                              <input className="input__field input__field--hoshi" value={this.state.inputValue["pwd"]} onFocus={this.onIputFocus.bind(this,"pwd")} onBlur={this.onInputBlur.bind(this,"pwd")} onChange={this.onInputChange.bind(this,"pwd")} ref="pwd" type="password" id="pwd" aria-labelledby="password"/>
                              <label className="input__label input__label--hoshi input__label--hoshi-color-1" for="pwd">
                                <span className="input__label-content input__label-content--hoshi candidateLbl" id="password">Password</span>
                              </label>
                            </span> 

               </li>
               <li className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                          <span className={this.state.inputlabelArray["confirmpwd"] ? "input input--hoshi input--filled llabelSpan" : "input input--hoshi llabelSpan"}>
                              <input className="input__field input__field--hoshi" value={this.state.inputValue["confirmpwd"]} onFocus={this.onIputFocus.bind(this,"confirmpwd")} onBlur={this.onInputBlur.bind(this,"confirmpwd")} onChange={this.onInputChange.bind(this,"confirmpwd")} ref="confirmpwd" type="password" id="confirmpwd" aria-labelledby="confirmpassword"/>
                              <label className="input__label input__label--hoshi input__label--hoshi-color-1" for="confirmpwd">
                                <span className="input__label-content input__label-content--hoshi candidateLbl" id="confirmpassword">Confirm Password</span>
                              </label>
                            </span> 

               </li>
              </ul>
              <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <button className="pull-right release-btn mt20" onClick={this.showPop}>sign up</button>
              </div>
              <Success show={this.state.showpop} hidePop={this.hidePop}/>
            </div>
          </div>
          <div className="col-lg-4 col-md-4 col-sm-12 col-xs-12 login_section">
            <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 nopad">
              <h3>Login</h3>
              <ul className="col-xs-12 forms_ul nopad manageUL"> 
              <li className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                          <span className={this.state.inputlabelArray["user_login"] ? "input input--hoshi input--filled llabelSpan" : "input input--hoshi llabelSpan"}>
                              <input className="input__field input__field--hoshi" value={this.state.inputValue["user_login"]} onFocus={this.onIputFocus.bind(this,"user_login")} onBlur={this.onInputBlur.bind(this,"user_login")} onChange={this.onInputChange.bind(this,"user_login")} ref="user_login" type="text" id="user_login" aria-labelledby="user name"/>
                              <label className="input__label input__label--hoshi input__label--hoshi-color-1" for="user_login">
                                <span className="input__label-content input__label-content--hoshi candidateLbl" id="user name">User Name</span>
                              </label>
                            </span> 

               </li>
                <li className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                          <span className={this.state.inputlabelArray["pwd_login"] ? "input input--hoshi input--filled llabelSpan" : "input input--hoshi llabelSpan"}>
                              <input className="input__field input__field--hoshi" value={this.state.inputValue["pwd_login"]} onFocus={this.onIputFocus.bind(this,"pwd_login")} onBlur={this.onInputBlur.bind(this,"pwd_login")} onChange={this.onInputChange.bind(this,"pwd_login")} ref="pwd_login" type="password" id="pwd_login" aria-labelledby="password_login"/>
                              <label className="input__label input__label--hoshi input__label--hoshi-color-1" for="pwd_login">
                                <span className="input__label-content input__label-content--hoshi candidateLbl" id="password_login">Password</span>
                              </label>
                            </span> 

               </li>
               </ul>
                <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <Link to="chartHomePage"><button className="pull-right release-btn mt20">login</button></Link>
              </div>
            </div>
          </div>
          </div>
        </div>
      </div>
      </div>
    );
  }
});


module.exports = Login;