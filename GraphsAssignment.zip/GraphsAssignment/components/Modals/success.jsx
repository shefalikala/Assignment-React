import React from 'react';
import ReactDOM from 'react-dom';
import ReactBootstrap from 'react-bootstrap';
import  {FormGroup ,Radio ,SplitButton ,tooltip ,DropdownButton,popover ,title,Modal ,ButtonToolbar,Button,Label,Popover,Tooltip,OverlayTrigger,Table,Tabs,Tab,Input, Nav,NavItem,NavDropdown,MenuItem, Accordion,Panel, PanelGroup, Carousel,ProgressBar } from 'react-bootstrap'; 
import { Link, Router, Route, IndexRoute,browserHistory, hashHistory ,History} from "react-router";

const SuccessModal = React.createClass({
    getInitialState: function () {
    return {  
        
    }
  },
  hidepopup()
  {
   
    this.props.hidePop();
  },
  render:function() {


    return<div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 nopad modal_div">
            <Modal show={this.props.show} className="success_pop">
              <Modal.Body>
                <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 nopad pop_header_div">
                  <span className="pull-left pop_title">Success Message</span>
                  <button className="icon-close pop_close" onClick={this.hidepopup} aria-label="close popup"></button>
                </div>
                <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 nopad pop_msg">
                 Registered Successfully! Login to continue.....
                </div>
                <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 nopad pop_footer">
                  <button aria-label="ok" className="pop_ok_btn pull-right" onClick={this.hidepopup}>OK</button>
                </div>
              </Modal.Body>
            </Modal>  
             
          </div>

  }
});


module.exports = SuccessModal;




