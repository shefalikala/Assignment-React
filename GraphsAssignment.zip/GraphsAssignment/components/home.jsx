import React from 'react';
import ReactDOM from 'react-dom';
import ReactBootstrap from 'react-bootstrap';
import Login from './login.jsx';


const Home = React.createClass({



 getInitialState() {
    return {};
      
  },



 


  render() {

    return (
    
    <div className="container">
     <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 nopad MainTabsContainer">
     <Login />
  
     </div>
      </div>
    );
  }
});


module.exports = Home;