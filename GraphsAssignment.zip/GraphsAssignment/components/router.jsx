import React from 'react';
import ReactDOM from 'react-dom';
import { Link, Router, Route, IndexRoute, hashHistory } from "react-router";
import ReactBootstrap from 'react-bootstrap';

import  { Radio,ListGroupItem,ListGroup,Carousel ,FormGroup ,ControlLabel ,FormControl ,Label,Accordion, Panel, Modal ,Button, ButtonGroup, OverlayTrigger , Popover    } from 'react-bootstrap';

import Home from './home.jsx';
import Header from './header.jsx';
import ChartHomePage from './Charts/chartHomePage.jsx';


{/*********************************************************************/}



ReactDOM.render((
  <Router onUpdate={() => window.scrollTo(0, 0)} >
		<Route path="/" component={Home} ></Route>		
		<Route path="header" component={Header}></Route>
	    <Route path="chartHomePage" component={ChartHomePage}></Route>
		

  </Router>
), document.getElementById('root'))