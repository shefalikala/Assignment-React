import React from 'react';
import ReactDOM from 'react-dom';
import ReactBootstrap from 'react-bootstrap';
import  {FormGroup ,Radio ,SplitButton ,tooltip ,DropdownButton,popover ,title,Modal ,ButtonToolbar,Button,Label,Popover,Tooltip,OverlayTrigger,Table,Tabs,Tab,Input, Nav,NavItem,NavDropdown,MenuItem, Accordion,Panel, PanelGroup, Carousel,ProgressBar } from 'react-bootstrap'; 
import { Link, Router, Route, IndexRoute,browserHistory, hashHistory ,History} from "react-router";

const Header = React.createClass({
    getInitialState: function () {
    return {  
     
    }
  },

  render:function() {


    return<header className="col-lg-12 col-md-12 col-sm-12 col-xs-12 nopad header_cls">

    
     
              <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 nopad">
                  
                  <span className="HeaderText">Charts</span>
                  
              </div>
                                  </header>

  }
});


module.exports = Header;




