import React from 'react';
import ReactDOM from 'react-dom';
import ReactBootstrap from 'react-bootstrap';
import  {FormGroup ,Radio ,SplitButton ,tooltip ,DropdownButton,popover ,title,Modal ,ButtonToolbar,Button,Label,Popover,Tooltip,OverlayTrigger,Table,Tabs,Tab,Input, Nav,NavItem,NavDropdown,MenuItem, Accordion,Panel, PanelGroup, Carousel,ProgressBar } from 'react-bootstrap'; 
import { Link, Router, Route, IndexRoute,browserHistory, hashHistory ,History} from "react-router";
import Select from 'react-select';

import Header from '../header.jsx';


const LeftMenu = React.createClass({
    getInitialState: function () {
    return {  
     
    }
  },
  showGraph(index)
  {
  console.log("hfgvh",this.props.graph);
    this.props.showOther(index);
  },
  render:function() {

    return <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 nopad">
       <ul className="col-xs-12 nopad left_ul">
         <li className={this.props.graph == 1 ? "col-xs-12 nopad active" : "col-xs-12 nopad "} onClick={this.showGraph.bind(this,1)}>
           Pie Chart
         </li>
         <li className={this.props.graph == 2 ? "col-xs-12 nopad active" : "col-xs-12 nopad "} onClick={this.showGraph.bind(this,2)}>
           Bar Chart
         </li>
         <li className={this.props.graph == 3 ? "col-xs-12 nopad active" : "col-xs-12 nopad "} onClick={this.showGraph.bind(this,3)}>
           Line Chart
         </li>

       </ul>
      </div>


  }
});


module.exports = LeftMenu;




