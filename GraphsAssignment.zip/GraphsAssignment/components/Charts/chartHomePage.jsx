import React from 'react';
import ReactDOM from 'react-dom';
import ReactBootstrap from 'react-bootstrap';
import  {FormGroup ,Radio ,SplitButton ,tooltip ,DropdownButton,popover ,title,Modal ,ButtonToolbar,Button,Label,Popover,Tooltip,OverlayTrigger,Table,Tabs,Tab,Input, Nav,NavItem,NavDropdown,MenuItem, Accordion,Panel, PanelGroup, Carousel,ProgressBar } from 'react-bootstrap'; 
import { Link, Router, Route, IndexRoute,browserHistory, hashHistory ,History} from "react-router";
import Select from 'react-select';

import Header from '../header.jsx';
import LeftMenu from './leftMenu.jsx';

import PieChart from './pieChart.jsx'; 
import Barchart from './barchart.jsx';
import LineChart from './lineChart.jsx';

const ChartHomePage = React.createClass({
    getInitialState: function () {
    return {  
     graph:1
    }
  },
  showOther(index)
  {
        this.setState({graph:index})  
  },

  render:function() {
    return  <div className="container">
     <Header/>
     <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 nopad MainTabsContainer back-white">
        <div className="col-lg-2 col-md-2 col-sm-2 col-xs-12 nopad">
          <LeftMenu showOther={this.showOther} graph={this.state.graph}/>
        </div>
        <div className="col-lg-10 col-md-10 col-sm-10 col-xs-12 nopad">
         
          <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 nopad">

              {this.state.graph == 1 ? <PieChart /> : null}
              {this.state.graph == 2 ?<Barchart /> : null}
              {this.state.graph == 3 ?<LineChart /> : null}
          </div>
        </div>
      </div>


 </div>


  }
});


module.exports = ChartHomePage;




